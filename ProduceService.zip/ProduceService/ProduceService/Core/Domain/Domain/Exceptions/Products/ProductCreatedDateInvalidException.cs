﻿namespace Domain.Exceptions.Products
{
    public class ProductCreatedDateInvalidException : Exception
    {
    }
}
