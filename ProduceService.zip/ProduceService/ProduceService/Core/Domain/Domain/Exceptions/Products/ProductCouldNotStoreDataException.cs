﻿namespace Domain.Exceptions.Products
{
    public class ProductCouldNotStoreDataException : Exception
    {
    }
}
