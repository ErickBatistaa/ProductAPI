﻿namespace Domain.Exceptions.Products
{
    public class ProductNotFoundException : Exception
    {
    }
}
