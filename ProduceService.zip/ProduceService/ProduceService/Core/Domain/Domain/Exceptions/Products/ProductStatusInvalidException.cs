﻿namespace Domain.Exceptions.Products
{
    public class ProductStatusInvalidException : Exception
    {
    }
}
