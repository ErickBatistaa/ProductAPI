﻿namespace Domain.Exceptions.Products
{
    public class ProductMissingRequiredInformationException : Exception
    {
    }
}
