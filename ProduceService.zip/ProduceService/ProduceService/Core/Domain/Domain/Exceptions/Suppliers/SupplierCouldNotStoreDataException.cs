﻿namespace Domain.Exceptions.Suppliers
{
    public class SupplierCouldNotStoreDataException : Exception
    {
    }
}
