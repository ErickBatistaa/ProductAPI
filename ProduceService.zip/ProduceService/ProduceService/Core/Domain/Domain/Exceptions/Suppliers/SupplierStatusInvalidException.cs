﻿namespace Domain.Exceptions.Suppliers
{
    public class SupplierStatusInvalidException : Exception
    {
    }
}
