﻿namespace Domain.Exceptions.Suppliers
{
    public class SupplierMissingRequiredInformationException : Exception
    {
    }
}
