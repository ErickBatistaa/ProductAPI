﻿namespace Domain.Exceptions.Suppliers
{
    public class SupplierNotFoundException : Exception
    {
    }
}
