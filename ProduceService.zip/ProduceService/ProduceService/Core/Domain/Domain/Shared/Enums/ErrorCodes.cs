﻿namespace Domain.Shared.Enums
{
    public enum ErrorCodes
    {
        // Products status codes 1 to 20
        PRODUCT_NOT_FOUND = 1,
        PRODUCT_COULD_NOT_STORE_DATA = 2,
        PRODUCT_MISSING_REQUIRED_INFORMATION = 3,

        // Suppliers status codes 21 to 40
        SUPPLIER_NOT_FOUND = 21,
        SUPPLIER_COULD_NOT_STORE_DATA = 22,
        SUPPLIER_MISSING_REQUIRED_INFORMATION = 23
    }
}
