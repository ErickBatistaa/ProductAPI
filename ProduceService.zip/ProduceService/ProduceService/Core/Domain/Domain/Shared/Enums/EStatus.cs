﻿namespace Domain.Shared.Enums
{
    public enum EStatus
    {
        Inativo = 0,
        Ativo = 1
    }
}
