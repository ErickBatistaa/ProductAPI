﻿using Domain.Exceptions.Products;
using Domain.Shared.Enums;

namespace Domain.Entities.Products
{
    public class Product
    {
        public int Id { get; set; }
        public string? Description { get; set; }
        public EStatus Status { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime ValidateDate { get; set; } = DateTime.UtcNow.AddDays(1);

        public void ValidateState()
        {
            if (string.IsNullOrEmpty(this.Description) ||
                this.CreatedDate == default(DateTime) || 
                this.ValidateDate == default(DateTime))
            {
                throw new ProductMissingRequiredInformationException();
            }

            if (this.CreatedDate >= this.ValidateDate)
            {
                throw new ProductCreatedDateInvalidException();
            }
        }
    }
}
