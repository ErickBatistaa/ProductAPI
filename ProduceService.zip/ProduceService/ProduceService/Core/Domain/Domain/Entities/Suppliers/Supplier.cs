﻿using Domain.Exceptions.Suppliers;
using Domain.Shared.Enums;

namespace Domain.Entities.Suppliers
{
    public class Supplier
    {
        public int Id { get; set; }
        public string? Description { get; set; }
        public double CNPJ { get; set; }
        public EStatus Status { get; set; }

        public void ValidateState()
        {
            if (string.IsNullOrEmpty(this.Description) || 
                this.CNPJ == 0)
            {
                throw new SupplierMissingRequiredInformationException();
            }
        }
    }
}
