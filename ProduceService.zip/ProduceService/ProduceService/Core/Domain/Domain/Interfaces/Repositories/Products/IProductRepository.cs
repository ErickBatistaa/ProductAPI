﻿using Domain.Entities.Products;

namespace Domain.Interfaces.Repositories.Products
{
    public interface IProductRepository
    {
        Task<Product> GetById(int id);
        Task <List<Product>> GetAll();
        Task<int> Create(Product product);
        Task<int> Update(Product product);
    }
}
