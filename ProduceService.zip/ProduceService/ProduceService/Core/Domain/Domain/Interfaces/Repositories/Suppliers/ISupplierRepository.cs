﻿using Domain.Entities.Suppliers;

namespace Domain.Interfaces.Repositories.Suppliers
{
    public interface ISupplierRepository
    {
        Task<Supplier> GetById(int id);
        Task <List<Supplier>> GetAll();
        Task<int> Create(Supplier supplier);
        Task<int> Update(Supplier supplier);
    }
}
