﻿using Data.IoC.AutoMapper;
using Microsoft.Extensions.DependencyInjection;

namespace Data.IoC
{
    public static class InjectionConfig
    {
        public static void ConfigureMapper(IServiceCollection services)
        {
            AutoMapperConfig.Register(services);
        }
    }
}
