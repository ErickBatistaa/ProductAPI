﻿using Application.DTOs.Products;
using Application.DTOs.Suppliers;
using AutoMapper;
using Domain.Entities.Products;
using Domain.Entities.Suppliers;
using Microsoft.Extensions.DependencyInjection;

namespace Data.IoC.AutoMapper
{
    public class AutoMapperConfig
    {
        internal static void Register(IServiceCollection service)
        {
            var configMapper = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<ProductDto, Product>();
                cfg.CreateMap<Product, ProductDto>();
                cfg.CreateMap<SupplierDto, Supplier>();
                cfg.CreateMap<Supplier, SupplierDto>();
            });

            IMapper mapper = configMapper.CreateMapper();
            service.AddSingleton(mapper);
        }
    }
}
