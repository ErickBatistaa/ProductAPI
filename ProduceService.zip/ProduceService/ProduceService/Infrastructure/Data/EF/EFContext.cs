﻿using Domain.Entities.Products;
using Domain.Entities.Suppliers;
using Microsoft.EntityFrameworkCore;

namespace Data.EF
{
    public class EFContext : DbContext
    {
        public EFContext(DbContextOptions<EFContext> options) : base(options) { }

        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Supplier> Suppliers { get; set; }
    }
}
