﻿using Data.EF;
using Domain.Entities.Products;
using Domain.Interfaces.Repositories.Products;

namespace Data.Repositories.Products
{
    public class ProductRepository : IProductRepository
    {
        private readonly EFContext _efContext;

        public ProductRepository(EFContext efContext)
        {
            _efContext = efContext;
        }

        public async Task<int> Create(Product product)
        {
            _efContext.Products.Add(product);
            await _efContext.SaveChangesAsync();
            return product.Id;
        }

        public async Task<List<Product>> GetAll()
        {
            var productList = _efContext.Products.ToList();
            await _efContext.SaveChangesAsync();
            return productList;
        }

        public async Task<Product> GetById(int id)
        {
            var product = _efContext.Products.Where(x => x.Id == id).First();
            await _efContext.SaveChangesAsync();
            return product;
        }

        public async Task<int> Update(Product product)
        {
            var productDb = _efContext.Products.Where(x => x.Id == product.Id).First();
            _efContext.Products.Entry(productDb).CurrentValues.SetValues(product);
            await _efContext.SaveChangesAsync();
            return product.Id;
        }
    }
}
