﻿using Data.EF;
using Domain.Entities.Suppliers;
using Domain.Interfaces.Repositories.Suppliers;

namespace Data.Repositories.Suppliers
{
    public class SupplierRepository : ISupplierRepository
    {
        private readonly EFContext _efContext;

        public SupplierRepository(EFContext efContext)
        {
            _efContext = efContext;
        }

        public async Task<int> Create(Supplier supplier)
        {
            _efContext.Suppliers.Add(supplier);
            await _efContext.SaveChangesAsync();
            return supplier.Id;
        }

        public async Task<List<Supplier>> GetAll()
        {
            var supplierList = _efContext.Suppliers.ToList();
            await _efContext.SaveChangesAsync();
            return supplierList;
        }

        public async Task<Supplier> GetById(int id)
        {
            var supplier = _efContext.Suppliers.Where(x => x.Id == id).First();
            await _efContext.SaveChangesAsync();
            return supplier;
        }

        public async Task<int> Update(Supplier supplier)
        {
            var supplierDb = _efContext.Suppliers.Where(x => x.Id == supplier.Id).First();
            _efContext.Suppliers.Entry(supplierDb).CurrentValues.SetValues(supplier);
            await _efContext.SaveChangesAsync();
            return supplier.Id;
        }
    }
}
