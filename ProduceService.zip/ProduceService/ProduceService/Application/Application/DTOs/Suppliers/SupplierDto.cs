﻿using Domain.Shared.Enums;

namespace Application.DTOs.Suppliers
{
    public class SupplierDto
    {
        public int Id { get; set; }
        public string? Description { get; set; }
        public double CNPJ { get; set; }
        public EStatus Status { get; set; }
    }
}
