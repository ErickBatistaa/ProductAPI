﻿using Domain.Shared.Enums;

namespace Application.DTOs.Products
{
    public class ProductDto
    {
        public int Id { get; set; }
        public string? Description { get; set; }
        public EStatus Status { get; set; }
    }
}
