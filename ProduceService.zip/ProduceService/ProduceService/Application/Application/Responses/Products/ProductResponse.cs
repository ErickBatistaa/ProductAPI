﻿using Application.DTOs.Products;
using Domain.Base;

namespace Application.Responses.Products
{
    public class ProductResponse : BaseResponse
    {
        public ProductDto? Data { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ValidateDate { get; set; }

        public ProductResponse() { }
        public ProductResponse(ProductDto? data, DateTime? createdDate, DateTime? validateDate)
        {
            Data = data;
            CreatedDate = createdDate;
            ValidateDate = validateDate;
        }
        public ProductResponse(ProductDto data)
        {
            Data = data;
        }
    }
}
