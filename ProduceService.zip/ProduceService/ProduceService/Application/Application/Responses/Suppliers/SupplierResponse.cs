﻿using Application.DTOs.Suppliers;
using Domain.Base;

namespace Application.Responses.Suppliers
{
    public class SupplierResponse : BaseResponse
    {
        public SupplierDto Data { get; set; }
    }
}
