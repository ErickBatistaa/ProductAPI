﻿using Application.DTOs.Products;
using Application.Requests.Products;
using Application.Responses.Products;
using Application.Services.Interfaces.Products;
using AutoMapper;
using Domain.Entities.Products;
using Domain.Exceptions.Products;
using Domain.Interfaces.Repositories.Products;
using Domain.Shared.Enums;

namespace Application.Services.Products
{
    public class ProductServices : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly IMapper _mapper;

        public ProductServices(IProductRepository productRepository,
                               IMapper mapper) 
        {
            _productRepository = productRepository;
            _mapper = mapper;
        }

        public async Task<ProductResponse> CreateProduct(ProductRequest request)
        {
            if (request.Data.Status == EStatus.Inativo)
                throw new ProductStatusInvalidException();

            var product = _mapper.Map<Product>(request.Data);
            product.ValidateState();
            var result = await _productRepository.Create(product);
            request.Data.Id = result;

            return new ProductResponse
            {
                Success = true,
                Data = request.Data,
            };
        }

        public async Task<ProductResponse> DeleteProduct(int productId)
        {
            if (productId == 0) 
                throw new ProductMissingRequiredInformationException();

            var product = await _productRepository.GetById(productId);
            product.Status = EStatus.Inativo;
            var result = await _productRepository.Update(product);

            return new ProductResponse
            {
                Success = true,
                Data = new ProductDto { Id = result }
            };
        }

        public async Task<List<ProductResponse>> GetAllProducts()
        {
            var result = await _productRepository.GetAll();
            var productList = new List<ProductResponse>();
            var productDto = new ProductDto();

            foreach (var product in result)
            {
                productDto = _mapper.Map<ProductDto>(product);
                productList.Add(new ProductResponse { 
                                    Success = true, 
                                    Data = productDto,
                                    CreatedDate = product.CreatedDate,
                                    ValidateDate = product.ValidateDate,
                                });
            }

            return productList;
        }

        public async Task<ProductResponse> GetProductById(int productId)
        {
            if (productId == 0)
                throw new ProductMissingRequiredInformationException();
            
            var result = await _productRepository.GetById(productId);
            var productDto = _mapper.Map<ProductDto>(result);

            return new ProductResponse
            {
                Success = true,
                Data = productDto,
                CreatedDate = result.CreatedDate,
                ValidateDate = result.ValidateDate
            };
        }

        public async Task<ProductResponse> UpdateProduct(ProductRequest request)
        {
            var product = _mapper.Map<Product>(request.Data);
            product.ValidateState();
            var result = await _productRepository.Update(product);

            return new ProductResponse
            {
                Success = true,
                Data = new ProductDto { Id = result }
            };
        }
    }
}
