﻿using Application.Requests.Products;
using Application.Responses.Products;

namespace Application.Services.Interfaces.Products
{
    public interface IProductService
    {
        Task<ProductResponse> CreateProduct(ProductRequest request);
        Task<ProductResponse> UpdateProduct(ProductRequest request);
        Task<ProductResponse> DeleteProduct(int productId);
        Task<ProductResponse> GetProductById(int productId);
        Task<List<ProductResponse>> GetAllProducts();
    }
}
