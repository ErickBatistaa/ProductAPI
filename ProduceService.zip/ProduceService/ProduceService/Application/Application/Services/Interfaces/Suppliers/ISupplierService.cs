﻿using Application.Requests.Suppliers;
using Application.Responses.Suppliers;

namespace Application.Services.Interfaces.Suppliers
{
    public interface ISupplierService
    {
        Task<SupplierResponse> CreateSupplier(SupplierRequest request);
        Task<SupplierResponse> UpdateSupplier(SupplierRequest request);
        Task<SupplierResponse> DeleteSupplier(int supplierId);
        Task<SupplierResponse> GetSupplierById(int supplierId);
        Task <List<SupplierResponse>> GetAllSuppliers();
    }
}
