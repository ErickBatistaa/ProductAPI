﻿using Application.DTOs.Suppliers;
using Application.Requests.Suppliers;
using Application.Responses.Suppliers;
using Application.Services.Interfaces.Suppliers;
using AutoMapper;
using Domain.Entities.Suppliers;
using Domain.Exceptions.Suppliers;
using Domain.Interfaces.Repositories.Suppliers;
using Domain.Shared.Enums;

namespace Application.Services.Suppliers
{
    public class SupplierServices : ISupplierService
    {
        private readonly ISupplierRepository _supplierRepository;
        private readonly IMapper _mapper;

        public SupplierServices(ISupplierRepository supplierRepository,
                                IMapper mapper) 
        {
            _supplierRepository = supplierRepository;
            _mapper = mapper;
        }

        public async Task<SupplierResponse> CreateSupplier(SupplierRequest request)
        {
            if (request.Data.Status == EStatus.Inativo)
                throw new SupplierStatusInvalidException();

            var supplier = _mapper.Map<Supplier>(request.Data);
            supplier.ValidateState();
            var result = await _supplierRepository.Create(supplier);
            request.Data.Id = result;

            return new SupplierResponse
            {
                Success = true,
                Data = request.Data
            };
        }

        public async Task<SupplierResponse> DeleteSupplier(int supplierId)
        {
            if (supplierId == 0)
                throw new SupplierMissingRequiredInformationException();

            var supplier = await _supplierRepository.GetById(supplierId);
            supplier.Status = EStatus.Inativo;
            var result = await _supplierRepository.Update(supplier);
            
            return new SupplierResponse
            {
                Success = true,
                Data = new SupplierDto { Id = result }
            };
        }

        public async Task<List<SupplierResponse>> GetAllSuppliers()
        {
            var result = await _supplierRepository.GetAll();
            var supplierList = new List<SupplierResponse>();
            var supplierDto = new SupplierDto();

            foreach (var supplier in result)
            {
                supplierDto = _mapper.Map<SupplierDto>(supplier);
                supplierList.Add(new SupplierResponse {
                                    Success = true, 
                                    Data = supplierDto
                                });
            }

            return supplierList;
        }

        public async Task<SupplierResponse> GetSupplierById(int supplierId)
        {
            if (supplierId == 0)
                throw new SupplierMissingRequiredInformationException();

            var result = await _supplierRepository.GetById(supplierId);
            var supplierDto = _mapper.Map<SupplierDto>(result);

            return new SupplierResponse
            {
                Success = true,
                Data = supplierDto
            };
        }

        public async Task<SupplierResponse> UpdateSupplier(SupplierRequest request)
        {
            var supplier = _mapper.Map<Supplier>(request.Data);
            supplier.ValidateState();
            var result = await _supplierRepository.Update(supplier);

            return new SupplierResponse
            {
                Success = true,
                Data = new SupplierDto { Id = result }
            };
        }
    }
}
