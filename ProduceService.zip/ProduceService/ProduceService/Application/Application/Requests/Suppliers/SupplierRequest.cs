﻿using Application.DTOs.Suppliers;

namespace Application.Requests.Suppliers
{
    public class SupplierRequest
    {
        public SupplierDto Data { get; set; }
    }
}
