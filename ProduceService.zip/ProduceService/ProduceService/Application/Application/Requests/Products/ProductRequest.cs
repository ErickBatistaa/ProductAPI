﻿using Application.DTOs.Products;

namespace Application.Requests.Products
{
    public class ProductRequest
    {
        public ProductDto Data { get; set; }
    }
}
