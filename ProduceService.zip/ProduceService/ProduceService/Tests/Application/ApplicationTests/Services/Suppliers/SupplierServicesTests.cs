﻿using Domain.Entities.Suppliers;

namespace ApplicationTests.Services.Suppliers
{
    public class SupplierServicesTests
    {
        [SetUp]
        public void Setup ()
        {

        }

        [Test]
        public void ShouldNotCreateWhenDescriptionIsNull()
        {
            var supplier = new Supplier();
            supplier.Description = null;
            Assert.IsNull(supplier.Description);
        }

        [Test]
        public void ShouldNotCreateWhenCNPJIsNull()
        {
            var supplier = new Supplier();
            supplier.CNPJ = 0;
            Assert.IsNotNull(supplier.CNPJ);
        }
    }
}
