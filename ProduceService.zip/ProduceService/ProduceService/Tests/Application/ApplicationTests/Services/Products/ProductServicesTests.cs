﻿using Domain.Entities.Products;
using Domain.Shared.Enums;

namespace ApplicationTests.Services.Products
{
    public class ProductServicesTests
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void ShouldNotInsertWhenDescriptionIsNull()
        {
            var product = new Product();
            product.Description = null;
            Assert.IsNull(product.Description);
        }

        [Test]
        public void ShouldNotInsertWhenStatusIsInactive() 
        {
            var product = new Product();
            product.Status = EStatus.Inativo;
            Assert.AreNotEqual(EStatus.Ativo, product.Status);
        }

        [Test]
        public void ShouldNotInsertWhenCreatedDateIsBiggerThanValidateDate()
        {
            var product = new Product();
            Assert.AreNotEqual(product.ValidateDate, product.CreatedDate);
        }


    }
}
