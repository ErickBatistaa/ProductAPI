﻿using Application.DTOs.Products;
using Application.DTOs.Suppliers;
using Application.Requests.Products;
using Application.Requests.Suppliers;
using Application.Services.Interfaces.Products;
using Microsoft.AspNetCore.Mvc;

namespace ProduceAPI.Controllers.Products
{
    [ApiController]
    [Route("Products")]
    public class ProductController : ControllerBase
    {
        private readonly ILogger<ProductController> _logger;
        private readonly IProductService _productService;

        public ProductController(ILogger<ProductController> logger, IProductService productService)
        {
            _logger = logger;
            _productService = productService;
        }

        [HttpPost]
        public async Task<ActionResult<ProductDto>> Create([FromBody] ProductDto product)
        {
            try
            {
                var request = new ProductRequest
                {
                    Data = product
                };

                var result = await _productService.CreateProduct(request);

                if (result.Success)
                {
                    return Created("Supplier created successfully!", result.Data);
                }

                return StatusCode(404, "Unavailable System. Try again later.");

            }
            catch (Exception e)
            {
                _logger.LogError("Unavailable System. Try again later.");
                return BadRequest(e.Message);
            }
        }

        [HttpGet("id")]
        public async Task<ActionResult<ProductDto>> GetById([FromHeader] int productId)
        {
            try
            {
                var result = await _productService.GetProductById(productId);

                if (result.Success)
                {
                    return Ok(result);
                }

                return StatusCode(404, "Unavailable System. Try again later.");
            }
            catch (Exception e)
            {
                _logger.LogError("Unavailable System. Try again later.");
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public async Task<ActionResult<List<ProductDto>>> GetAll()
        {
            try
            {
                var result = await _productService.GetAllProducts();

                if (result.First().Success)
                {
                    return Ok(result);
                }

                return StatusCode(404, "Unavailable System. Try again later.");
            }
            catch (Exception e)
            {
                _logger.LogError("Unavailable System. Try again later.");
                return BadRequest(e.Message);
            }
        }

        [HttpPatch]
        public async Task<ActionResult<ProductDto>> Update([FromBody] ProductDto product)
        {
            try
            {
                var request = new ProductRequest { Data = product };

                var result = await _productService.UpdateProduct(request);

                if (result.Success)
                {
                    return Ok(result);
                }

                return StatusCode(404, "Unavailable System. Try again later.");
            }
            catch (Exception e)
            {
                _logger.LogError("Unavailable System. Try again later.");
                return BadRequest(e.Message);
            }
        }

        [HttpDelete("id")]
        public async Task<ActionResult<ProductDto>> Delete([FromHeader] int productId)
        {
            try
            {
                var result = await _productService.DeleteProduct(productId);

                if (result.Success)
                {
                    return Ok(result);
                }

                return StatusCode(404, "Unavailable System. Try again later.");
            }
            catch (Exception e)
            {
                _logger.LogError("Unavailable System. Try again later.");
                return BadRequest(e.Message);
            }
        }

    }
}
