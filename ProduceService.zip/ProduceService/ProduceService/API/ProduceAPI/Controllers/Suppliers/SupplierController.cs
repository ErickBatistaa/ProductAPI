﻿using Application.DTOs.Suppliers;
using Application.Requests.Suppliers;
using Application.Services.Interfaces.Suppliers;
using Microsoft.AspNetCore.Mvc;

namespace ProduceAPI.Controllers.Suppliers
{
    [ApiController]
    [Route("Suppliers")]
    public class SupplierController : ControllerBase
    {
        private readonly ILogger<SupplierController> _logger;
        private readonly ISupplierService _supplierService;

        public SupplierController(ILogger<SupplierController> logger, ISupplierService supplierService)
        {
            _logger = logger;
            _supplierService = supplierService;
        }

        [HttpPost] 
        public async Task<ActionResult<SupplierDto>> Create([FromBody] SupplierDto supplier)
        {
            try
            {
                var request = new SupplierRequest
                {
                    Data = supplier
                };

                var result = await _supplierService.CreateSupplier(request);
                return Created("Supplier created successfully!", result.Data);
            }
            catch (Exception)
            {
                _logger.LogError("Response with unknown ErrorCode returned");
                return BadRequest();
            }
        }

        [HttpGet("id")]
        public async Task<ActionResult<SupplierDto>> GetById([FromHeader] int supplierId)
        {
            try
            {
                var result = await _supplierService.GetSupplierById(supplierId);
                return Ok(result);
            }
            catch (Exception)
            {
                _logger.LogError("Response with unknown ErrorCode returned");
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<ActionResult<List<SupplierDto>>> GetAll()
        {
            try
            {
                var result = await _supplierService.GetAllSuppliers();
                return Ok(result);
            }
            catch (Exception)
            {
                _logger.LogError("Response with unknown ErrorCode returned");
                return BadRequest();
            }
        }

        [HttpPatch]
        public async Task<ActionResult<SupplierDto>> Update([FromBody] SupplierDto supplier)
        {
            try
            {
                var request = new SupplierRequest { Data = supplier };

                var result = await _supplierService.UpdateSupplier(request);
                return Ok(result);
            }
            catch (Exception)
            {
                _logger.LogError("Response with unknown ErrorCode returned");
                return BadRequest();
            }
        }

        [HttpDelete("id")]
        public async Task<ActionResult<SupplierDto>> Delete([FromHeader] int supplierId)
        {
            try
            {
                var result = await _supplierService.DeleteSupplier(supplierId);
                return Ok(result);
            }
            catch (Exception)
            {
                _logger.LogError("Response with unknown ErrorCode returned");
                return BadRequest();
            }
        }
    }
}
