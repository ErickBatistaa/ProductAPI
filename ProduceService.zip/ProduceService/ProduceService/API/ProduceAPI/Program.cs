using Application.Services.Interfaces.Products;
using Application.Services.Interfaces.Suppliers;
using Application.Services.Products;
using Application.Services.Suppliers;
using Data.EF;
using Data.IoC;
using Data.Repositories.Products;
using Data.Repositories.Suppliers;
using Domain.Interfaces.Repositories.Products;
using Domain.Interfaces.Repositories.Suppliers;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

#region DB writing up
var connectionstring = builder.Configuration.GetConnectionString("Main");
builder.Services.AddDbContext<EFContext>(options => options.UseSqlServer(connectionstring));
#endregion

#region IoC
builder.Services.AddScoped<IProductService, ProductServices>();
builder.Services.AddScoped<ISupplierService, SupplierServices>();
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<ISupplierRepository, SupplierRepository>();
InjectionConfig.ConfigureMapper(builder.Services);
#endregion


// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
